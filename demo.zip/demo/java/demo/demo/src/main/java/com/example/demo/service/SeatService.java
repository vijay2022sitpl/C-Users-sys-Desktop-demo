package com.example.demo.service;

import com.example.demo.dto.request.SeatRequest;
import com.example.demo.model.SeatModel;
import com.example.demo.repo.SeatRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import static com.example.demo.model.SeatModel.Type;
import static com.example.demo.model.SeatModel.Field;
import com.example.demo.util.Validation;

@Service
public class SeatService
{
	@Autowired
	private SeatRepo seatRepo;

	public SeatModel add(SeatRequest seatRequest)
	{
		Validation.validateNotNull(seatRequest,Field.seatNum,Field.type);
	
		SeatModel seatModel=new SeatModel();
		seatModel.setSeatNum(seatRequest.getSeatNum());
		seatModel.setType(seatRequest.getType());
		seatRepo.save(seatModel);
		return seatModel;
	}
}