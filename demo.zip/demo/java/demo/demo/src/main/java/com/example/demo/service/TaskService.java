package com.example.demo.service;

import com.example.demo.dto.request.TaskRequest;
import com.example.demo.model.TaskModel;
import com.example.demo.repo.TaskRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TaskService
{
	@Autowired
	private TaskRepo taskRepo;

	public TaskModel add(TaskRequest taskRequest)
	{
		TaskModel taskModel=new TaskModel();
		taskModel.setName(taskRequest.getName());
		taskModel.setDesc(taskRequest.getDesc());
		taskRepo.save(taskModel);
		return taskModel;
	}
	
	public TaskModel edit(TaskRequest taskRequest,String taskId)
	{
		TaskModel taskModel=taskRepo.findById(taskId).get();
		taskModel.setName(taskRequest.getName());
		taskModel.setDesc(taskRequest.getDesc());
		taskRepo.save(taskModel);
		return taskModel;
	}
}