package com.example.demo.util;

import java.util.*;

public class Document<T extends Enum<T>>
{
    public interface CallBackWithReturn<T> 
    {

    public T call();

    }

    public interface CallWithData<T>
    {
    public void call(T d);
    }

    private class Field
    {
        public CallBackWithReturn get;
        public CallWithData set;

        public Field(CallBackWithReturn get, CallWithData set)
         {
            this.get = get;
            this.set = set;
        }
    }       

    Map<T, Field> fields = new HashMap<>();

    protected Document() 
    {
        setFields();
    }

    protected void setFields()
     {
     }

    protected <U> void  add(T field, CallBackWithReturn<U> get, CallWithData<U> set) 
    {
        fields.put(field, new Field(get, set));
    }    

    public Object get(T field) 
    {
        if (!fields.containsKey(field)) 
        {
            return null;
        }

        return fields.get(field).get.call();
    }

}
