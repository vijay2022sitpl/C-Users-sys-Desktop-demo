package com.example.demo.service;

import com.example.demo.model.UserModel;
import com.example.demo.dto.request.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.repo.UserRepo;

@Service
public class UserService
{
	@Autowired
	private UserRepo userRepo;
	
	public UserModel add(UserRequest userRequest)
	{
		UserModel userModel=new UserModel();
		userModel.setName(userRequest.getName());
		userModel.setEmail(userRequest.getEmail());
		userModel.setAge(userRequest.getAge());
		userRepo.save(userModel);
		return userModel;
	}
	
	public UserModel edit(UserRequest userRequest,String userId)
	{
		UserModel userModel=userRepo.findById(userId).get();
		userModel.setName(userRequest.getName());
		userModel.setEmail(userRequest.getEmail());
		userModel.setAge(userRequest.getAge());
		userRepo.save(userModel);
		return userModel;
	}
	
}