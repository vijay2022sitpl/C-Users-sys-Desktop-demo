package com.example.demo.dto.request;

import com.example.demo.util.Document;
import static com.example.demo.model.SeatModel.Type;
import static com.example.demo.model.SeatModel.Field;

public class SeatRequest extends Document<Field>
{
	private Integer seatNum;
	private Type type;

	 protected void setFields()
	 {
	 	add(Field.seatNum,
	 		() -> getSeatNum(),
    		d -> setSeatNum(d)
		);

		add(Field.type,
	 		() -> getType(),
    		d -> setType(d)
		);
	 }

	 public Integer getSeatNum()
    {
        return seatNum;
    }

    public void setSeatNum(Integer seatnum)
    {
        this.seatNum=seatnum;
    }

    public Type getType()
    {
        return type;
    }

    public void setType(Type type)
    {
        this.type=type;
    }
}