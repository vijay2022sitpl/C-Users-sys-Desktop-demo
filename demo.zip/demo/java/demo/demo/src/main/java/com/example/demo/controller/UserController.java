package com.example.demo.controller;

import java.util.*;
import com.example.demo.dto.request.UserRequest;
import com.example.demo.service.UserService;
import com.example.demo.model.UserModel;
import com.example.demo.repo.UserRepo;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/user")
public class UserController
{
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRepo userRepo;
	
	@CrossOrigin(origins = "*")
    @PostMapping(value = "/add")
	public ResponseEntity add(@RequestBody UserRequest request)
	{
		UserModel result=userService.add(request);		//add data
		String data=new Gson().toJson(result);
		return ResponseEntity.ok(data);
	}
	
	@CrossOrigin(origins = "*")
    @PostMapping(value = "/edit")
	public ResponseEntity edit(@RequestBody UserRequest request,@RequestParam String userId)
	{
		UserModel result=userService.edit(request,userId);	//edit data;
		String data=new Gson().toJson(result);			
		return ResponseEntity.ok(data);
	}
	
	@CrossOrigin(origins = "*")
    @GetMapping(value = "/getAll")
	public ResponseEntity getAll()
	{
		List<UserModel> result = userRepo.findAll();		//All Id fetch
		String data=new Gson().toJson(result);
		return ResponseEntity.ok(data);
	}
	
	@CrossOrigin(origins = "*")
    @GetMapping(value = "/get")
	public ResponseEntity get(@RequestParam String userId)
	{
		Optional<UserModel> result = userRepo.findById(userId); //one Id fetch
		String data=new Gson().toJson(result);
		return ResponseEntity.ok(data);
	}
}