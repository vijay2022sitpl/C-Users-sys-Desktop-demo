package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service
public class HelloService {
	public int calculate()
	{
		int a=10,b=20;
		int c=a+b;
		return c;
	}
	public String yes()
	{
		String s="Baby";
		return s;
	}
	public String val()
	{
		String n="Vijay",e="vijay@gamil";
		String p="2345677";
		String c="Name:"+n+"\n"+"E-mail:"+e+"\n"+"Number:"+p;
		return (c);
	}
}