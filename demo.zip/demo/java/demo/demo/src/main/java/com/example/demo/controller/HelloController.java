package com.example.demo.controller;

import com.example.demo.service.HelloService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/hi") 
public class HelloController {
	
	@Autowired 
	HelloService helloService;
	
    @CrossOrigin(origins = "*")
    @GetMapping(value = "/hello") 				
    public ResponseEntity hello() {
		Integer c=helloService.calculate();			
		String d=helloService.yes();
		return ResponseEntity.ok("Good"+c+d);
    }
	
	@CrossOrigin(origins = "*")
    @GetMapping(value = "/hel") 
	public ResponseEntity hell() {
		String a="Height";
		return ResponseEntity.ok(a);
	}
	@CrossOrigin(origins = "*")
    @GetMapping(value = "/value") 
	public ResponseEntity value() {
		String a=helloService.val();
		return ResponseEntity.ok(a);
    }
	
}