package com.example.demo.dto.response;

import static com.example.demo.model.SeatModel.Type;

public class SeatResponse
{
	private Integer seatNum;
	private Type type;

    public SeatResponse(Integer seatNum,Type type)
    {
        this.seatNum=seatNum;
        this.type=type;
    }

	 public Integer getSeatNum()
    {
        return seatNum;
    }

    public void setSeatNum(Integer seatnum)
    {
        this.seatNum=seatnum;
    }

    public Type getType()
    {
        return type;
    }

    public void setType(Type type)
    {
        this.type=type;
    }
}