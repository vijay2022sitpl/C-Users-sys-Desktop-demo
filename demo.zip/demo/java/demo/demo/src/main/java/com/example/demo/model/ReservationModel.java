package com.example.demo.model;

import org.hibernate.annotations.GenericGenerator;
import javax.persistence.*;

@Entity
@Table(name="reservation_model")
public class ReservationModel
{
	@Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "reservation_id", columnDefinition = "VARCHAR(255)")
    private String name;
	private Integer date;
	@Column(name="\"from\"")
	private Integer from;
	@Column(name="\"to\"")
	private Integer to;
	private Integer amount;

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name=name;
	}

	public Integer getDate()
	{
		return date;
	}

	public void setDate(Integer date)
	{
		this.date=date;
	}

	public Integer getFrom()
	{
		return from;
	}

	public void setFrom(Integer from)
	{
		this.from=from;
	}

	public Integer getTo()
	{
		return to;
	}

	public void setTo(Integer to)
	{
		this.to=to;
	}

	public Integer getAmount()
	{
		return amount;
	}

	public void setAmount(Integer amount)
	{
		this.amount=amount;
	}
}