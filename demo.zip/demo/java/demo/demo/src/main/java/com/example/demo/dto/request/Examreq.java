package com.example.demo.dto.request;

public class Examreq
{
	private String name;
	private String address;
	private Integer mobile;
	
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	
	public String getAddress()
	{
		return address;
	}
	public void setAddress(String address)
	{
		this.address=address;
	}
	
	public Integer getMobile()
	{
		return mobile;
	}
	public void setName(Integer mobile)
	{
		this.mobile=mobile;
	}
}