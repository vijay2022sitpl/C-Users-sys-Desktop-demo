package com.example.demo.repo;

import com.example.demo.model.TaskModel;
import com.example.demo.dto.response.TaskResponse;
import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface TaskRepo extends JpaRepository<TaskModel, String>
{
	@Query("select a from TaskModel a")
	List<TaskModel> fetchAll();
	
	@Query("select a from TaskModel a where a.taskId = ?1")
	TaskModel fetchByTaskId(String taskId);
	
	@Query("select new com.example.demo.dto.response.TaskResponse(a.name,a.desc) from TaskModel a")
	List<TaskResponse> fetchAllTaskResponse();
	
	@Query("select new com.example.demo.dto.response.TaskResponse(a.name,a.desc) from TaskModel a where a.taskId= ?1")
	TaskResponse fetchTaskResponseByTaskId(String taskId);
}