package com.example.demo.controller;

import com.example.demo.model.TaskModel;
import com.example.demo.repo.TaskRepo;
import com.example.demo.dto.request.TaskRequest;
import com.example.demo.service.TaskService;
import java.util.*;
import com.example.demo.dto.response.TaskResponse;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value="/task")
public class TaskController
{
	@Autowired
	private TaskService taskService;
	
	@Autowired
	private TaskRepo taskRepo;
	
	@CrossOrigin(origins = "*")
    @PostMapping(value = "/add")
	public ResponseEntity add(@RequestBody TaskRequest request)
	{
		TaskModel result=taskService.add(request);
		String data=new Gson().toJson(result);
		return ResponseEntity.ok(data);
	}
	
	@CrossOrigin(origins = "*")
    @PostMapping(value = "/edit")
	public ResponseEntity add(@RequestBody TaskRequest request,@RequestParam String taskId)
	{
		TaskModel result=taskService.edit(request,taskId);
		String data=new Gson().toJson(result);
		return ResponseEntity.ok(data);
	}
	
	@CrossOrigin(origins = "*")
    @GetMapping(value = "/getAll")
	public ResponseEntity getAll()
	{
		List<TaskModel> result = taskRepo.findAll();		//All Id fetch
		String data=new Gson().toJson(result);
		return ResponseEntity.ok(data);
	}
	
	@CrossOrigin(origins = "*")
    @GetMapping(value = "/get")
	public ResponseEntity get(@RequestParam String taskId)
	{
		Optional<TaskModel> result=taskRepo.findById(taskId);
		String data=new Gson().toJson(result);
		return ResponseEntity.ok(data);
	}
	
	@CrossOrigin(origins = "*")
    @GetMapping(value = "/fetchAll")
	public ResponseEntity fetchAll()
	{
		List<TaskModel> result=taskRepo.fetchAll();
		String data=new Gson().toJson(result);
		return ResponseEntity.ok(data);
	}
	
	@CrossOrigin(origins = "*")
    @GetMapping(value = "/fetch")
	public ResponseEntity fetch(@RequestParam String taskId)
	{
		TaskModel result=taskRepo.fetchByTaskId(taskId);
		String data=new Gson().toJson(result);
		return ResponseEntity.ok(data);
	}
	
	@CrossOrigin(origins = "*")
    @GetMapping(value = "/part")
	public ResponseEntity part()
	{
		List<TaskResponse> result=taskRepo.fetchAllTaskResponse();
		String data=new Gson().toJson(result);
		return ResponseEntity.ok(data);
	}
	
	
	@CrossOrigin(origins = "*")
    @GetMapping(value = "/partid")
	public ResponseEntity partid(@RequestParam String taskId)
	{
		TaskResponse result=taskRepo.fetchTaskResponseByTaskId(taskId);
		String data=new Gson().toJson(result);
		return ResponseEntity.ok(data);
	}
}