package com.example.demo.controller;

import com.example.demo.dto.request.ReservationRequest;
//import com.example.demo.dto.response.ReservationResponse;
import com.example.demo.model.ReservationModel;
//import com.example.demo.repo.ReservationRepo;
import com.example.demo.service.ReservationService;
import java.util.*;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value="/reservation")
public class ReservationController
{
	@Autowired
	private ReservationService reservationService;
	
	@CrossOrigin(origins = "*")
    @PostMapping(value = "/add")
	public ResponseEntity add(@RequestBody ReservationRequest request)
	{
		ReservationModel result=reservationService.add(request);
		String data=new Gson().toJson(result);
		return ResponseEntity.ok(data);
	}
}