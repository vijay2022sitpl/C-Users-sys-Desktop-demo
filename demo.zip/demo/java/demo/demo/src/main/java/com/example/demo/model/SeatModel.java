package com.example.demo.model;

import org.hibernate.annotations.GenericGenerator;
import javax.persistence.*;

@Entity
@Table(name = "seat_model")
public class SeatModel
{
    public enum Type
    {
        SeatSleeper,
        SeatSitting
    }

    public enum Field
    {
        seatNum,
        type
    }
    
	@Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "seat_id", columnDefinition = "VARCHAR(255)")
    private String seatId;
    private Integer seatNum;
    private Type type;

    public String getSeatId()
    {
        return seatId;
    }

    public void setSeatNum(String seatId)
    {
        this.seatId=seatId;
    }

    public Integer getSeatNum()
    {
        return seatNum;
    }

    public void setSeatNum(Integer seatnum)
    {
        this.seatNum=seatnum;
    }

    public Type getType()
    {
        return type;
    }

    public void setType(Type type)
    {
        this.type=type;
    }
}
