package com.example.demo.service;

import com.example.demo.dto.request.ReservationRequest;
import com.example.demo.model.ReservationModel;
import com.example.demo.repo.ReservationRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReservationService
{
	@Autowired
	private ReservationRepo reservationRepo;

	public ReservationModel add(ReservationRequest reservationRequest)
	{
		ReservationModel reservationModel=new ReservationModel();
		reservationModel.setName(reservationRequest.getName());
		reservationModel.setDate(reservationRequest.getDate());
		reservationModel.setFrom(reservationRequest.getFrom());
		reservationModel.setTo(reservationRequest.getTo());
		reservationModel.setAmount(reservationRequest.getAmount());
		reservationRepo.save(reservationModel);
		return reservationModel;
	}
}