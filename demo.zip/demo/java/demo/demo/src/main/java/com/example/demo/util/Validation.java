package com.example.demo.util;

import java.util.*;

public class Validation
{
public static <T extends Enum<T>> void validateNotNull(Document<T> doc, T... fields)
  {
        for (T field : Arrays.asList(fields)) 
        {
            if (doc.get(field) == null)
            {
                throw new IllegalArgumentException(StringUtils.camelCaseToCapWords(field.toString()) + " is required.");
            }
        }
    }
}