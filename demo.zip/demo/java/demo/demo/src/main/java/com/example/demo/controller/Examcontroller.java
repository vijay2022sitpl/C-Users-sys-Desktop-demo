package com.example.demo.controller;

import com.example.demo.dto.request.Examreq;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/exam")
public class Examcontroller
{
	@CrossOrigin(origins = "*")
    @PostMapping(value = "/detail") 
	public ResponseEntity detail(@RequestBody Examreq req)
	{
		String s=new Gson().toJson(req);
		return ResponseEntity.ok(s);
	}
}