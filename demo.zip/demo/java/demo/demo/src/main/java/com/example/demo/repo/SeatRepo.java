package com.example.demo.repo;

import com.example.demo.model.SeatModel;
import static com.example.demo.model.SeatModel.Type;
import com.example.demo.dto.response.SeatResponse;
import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SeatRepo extends JpaRepository<SeatModel, String>
{

}