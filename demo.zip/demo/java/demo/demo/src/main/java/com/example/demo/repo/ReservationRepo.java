package com.example.demo.repo;

import com.example.demo.model.ReservationModel;
import com.example.demo.dto.response.ReservationResponse;
import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservationRepo extends JpaRepository<ReservationModel,String>
{

}
