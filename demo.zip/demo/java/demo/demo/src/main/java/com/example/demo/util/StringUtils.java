package com.example.demo.util;

public class StringUtils
{
	public static String capitalizeFully(final String text)
	 {
        String fullyCapitalizedText = "";
        for (String word : text.trim().split("\\W+"))
         {
            if (!word.isEmpty()) 
            {
                fullyCapitalizedText += (capitalize(word) + " ");
            }
        }
        return fullyCapitalizedText.trim();
    }

    private static String capitalize(final String line) 
    {
        return Character.toUpperCase(line.charAt(0)) + line.substring(1);
    }

	public static String camelCaseToCapWords(String text)
	{
        return capitalizeFully(String.join(" ",
             		org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(text)));
    }
}