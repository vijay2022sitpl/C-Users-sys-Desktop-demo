package com.example.demo.dto.request;

public class ReservationRequest
{
	private String name;
	private Integer date;
	private Integer from;
	private Integer to;
	private Integer amount;

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name=name;
	}

	public Integer getDate()
	{
		return date;
	}

	public void setDate(Integer date)
	{
		this.date=date;
	}

	public Integer getFrom()
	{
		return from;
	}

	public void setFrom(Integer from)
	{
		this.from=from;
	}

	public Integer getTo()
	{
		return to;
	}

	public void setTo(Integer to)
	{
		this.to=to;
	}

	public Integer getAmount()
	{
		return amount;
	}

	public void setAmount(Integer amount)
	{
		this.amount=amount;
	}
}